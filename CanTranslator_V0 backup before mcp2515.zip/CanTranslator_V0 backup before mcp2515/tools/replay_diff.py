#!/usr/bin/env python3
"""Phase 10C replay/differential harness for Mercedes RTF CAN logs.

Input format accepted:
    R,W204,timestamp,bus,ID,S,DLC,data

The harness parses raw captures, normalizes frames, calculates per-ID timing,
compares two traces, and can report mandatory-ID coverage. It never transmits
onto a CAN bus.
"""
from __future__ import annotations

import argparse
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

MANDATORY_IDS = {
    0x001, 0x06D, 0x073, 0x0D5, 0x0F1, 0x0F3,
    0x105, 0x14B, 0x17D, 0x1CD, 0x429,
}

@dataclass(frozen=True)
class Frame:
    timestamp: int
    bus: int
    can_id: int
    dlc: int
    data: bytes


def parse_hex_bytes(text: str, dlc: int) -> bytes:
    cleaned = text.replace(' ', '').replace('-', '').strip()
    if len(cleaned) % 2:
        raise ValueError(f"odd-length data field: {text!r}")
    raw = bytes.fromhex(cleaned)
    if len(raw) < dlc:
        raise ValueError(f"DLC {dlc} exceeds payload length {len(raw)}")
    return raw[:dlc]


def parse_line(line: str) -> Frame | None:
    line = line.strip()
    if not line or line.startswith('#'):
        return None
    fields = [f.strip() for f in line.split(',')]
    if len(fields) < 8 or fields[0] != 'R':
        return None
    # R,W204,timestamp,bus,ID,S,DLC,data
    try:
        timestamp = int(fields[2], 0)
        bus = int(fields[3], 0)
        can_id = int(fields[4], 0)
        dlc = int(fields[6], 0)
        data = parse_hex_bytes(fields[7], dlc)
    except (ValueError, IndexError) as exc:
        raise ValueError(f"Invalid CAN line: {line!r}: {exc}") from exc
    return Frame(timestamp, bus, can_id, dlc, data)


def read_frames(path: Path) -> list[Frame]:
    frames: list[Frame] = []
    with path.open('r', encoding='utf-8', errors='replace') as handle:
        for line_no, line in enumerate(handle, 1):
            try:
                frame = parse_line(line)
            except ValueError as exc:
                raise ValueError(f"{path}:{line_no}: {exc}") from exc
            if frame is not None:
                frames.append(frame)
    frames.sort(key=lambda f: f.timestamp)
    return frames


def mandatory_coverage(frames: Iterable[Frame]) -> dict[int, int]:
    counts = {can_id: 0 for can_id in sorted(MANDATORY_IDS)}
    for frame in frames:
        if frame.can_id in counts:
            counts[frame.can_id] += 1
    return counts


def periods(frames: Iterable[Frame]) -> dict[tuple[int, int], list[int]]:
    last: dict[tuple[int, int], int] = {}
    deltas: dict[tuple[int, int], list[int]] = {}
    for frame in frames:
        key = (frame.bus, frame.can_id)
        previous = last.get(key)
        if previous is not None:
            deltas.setdefault(key, []).append(frame.timestamp - previous)
        last[key] = frame.timestamp
    return deltas


def compare(expected: list[Frame], observed: list[Frame]) -> dict[str, int]:
    result = {
        'expected_frames': len(expected),
        'observed_frames': len(observed),
        'matched_in_order': 0,
        'payload_mismatches': 0,
        'missing_observed': 0,
        'extra_observed': 0,
    }
    n = min(len(expected), len(observed))
    for i in range(n):
        e, o = expected[i], observed[i]
        same_shape = (e.bus, e.can_id, e.dlc) == (o.bus, o.can_id, o.dlc)
        if same_shape and e.data == o.data:
            result['matched_in_order'] += 1
        elif same_shape:
            result['payload_mismatches'] += 1
    if len(expected) > len(observed):
        result['missing_observed'] = len(expected) - len(observed)
    elif len(observed) > len(expected):
        result['extra_observed'] = len(observed) - len(expected)
    return result


def print_summary(label: str, frames: list[Frame]) -> None:
    print(f"[{label}] frames={len(frames)}")
    by_bus = {1: 0, 2: 0}
    for frame in frames:
        by_bus[frame.bus] = by_bus.get(frame.bus, 0) + 1
    print(f"  bus1={by_bus.get(1,0)} bus2={by_bus.get(2,0)}")
    print("  mandatory coverage:")
    for can_id, count in mandatory_coverage(frames).items():
        print(f"    0x{can_id:03X}: {count}")
    print("  median periods:")
    for (bus, can_id), values in sorted(periods(frames).items()):
        if can_id not in MANDATORY_IDS or not values:
            continue
        median = statistics.median(values)
        print(f"    CAN{bus} 0x{can_id:03X}: {median} logger-units ({len(values)} intervals)")


def main() -> int:
    parser = argparse.ArgumentParser(description='Phase 10C CAN replay/differential analysis')
    parser.add_argument('expected', type=Path, help='reference RTF capture')
    parser.add_argument('--observed', type=Path, help='captured translator output')
    args = parser.parse_args()

    expected = read_frames(args.expected)
    print_summary('REFERENCE', expected)
    if args.observed:
        observed = read_frames(args.observed)
        print_summary('OBSERVED', observed)
        print('\nDIFFERENTIAL')
        for key, value in compare(expected, observed).items():
            print(f'  {key}: {value}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
