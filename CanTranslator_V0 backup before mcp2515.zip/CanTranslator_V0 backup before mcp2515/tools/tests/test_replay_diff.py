import tempfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parents[1]))
from replay_diff import read_frames, compare, mandatory_coverage


def write_trace(path: Path, rows: list[str]) -> None:
    path.write_text('\n'.join(rows) + '\n', encoding='utf-8')


def test_parse_and_coverage() -> None:
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / 'sample.rtf'
        write_trace(p, [
            'R,W204,100,1,0x0F3,S,8,DD FF 00 00 00 0A 10 00',
            'R,W204,112,2,0x0F1,S,8,00 00 00 00 00 00 00 00',
            'R,W204,124,2,0x0F3,S,8,12 34 00 00 00 00 20 00',
        ])
        frames = read_frames(p)
        assert len(frames) == 3
        assert frames[0].can_id == 0x0F3
        assert frames[1].bus == 2
        assert mandatory_coverage(frames)[0x0F3] == 2
        assert mandatory_coverage(frames)[0x0F1] == 1


def test_differential_exact_match() -> None:
    frames = []
    with tempfile.TemporaryDirectory() as td:
        p1 = Path(td) / 'a.rtf'
        p2 = Path(td) / 'b.rtf'
        row = 'R,W204,100,2,0x0F3,S,8,DD FF 00 00 00 0A 10 00'
        write_trace(p1, [row])
        write_trace(p2, [row])
        frames = read_frames(p1)
        observed = read_frames(p2)
        result = compare(frames, observed)
        assert result['matched_in_order'] == 1
        assert result['payload_mismatches'] == 0


def test_differential_payload_mismatch() -> None:
    with tempfile.TemporaryDirectory() as td:
        p1 = Path(td) / 'a.rtf'
        p2 = Path(td) / 'b.rtf'
        write_trace(p1, ['R,W204,100,2,0x0F3,S,8,DD FF 00 00 00 0A 10 00'])
        write_trace(p2, ['R,W204,100,2,0x0F3,S,8,DE FF 00 00 00 0A 10 00'])
        result = compare(read_frames(p1), read_frames(p2))
        assert result['payload_mismatches'] == 1
        assert result['matched_in_order'] == 0
