# Phase 10C — Replay / Differential Testing

## Scope

Phase 10C validates the recovered V0 firmware against the existing W204/W164 capture corpus without changing the firmware protocol model.

## Implemented in this baseline

- `tools/replay_diff.py`: read-only parser for the project's timestamped RTF format (`R,W204,timestamp,bus,ID,S,DLC,data`).
- Mandatory-ID coverage report for the Phase 8/9 core set.
- Per-bus/per-ID median-period calculation using the source logger units.
- Ordered differential comparison of reference and observed traces at ID, bus, DLC and payload levels.
- Focused host-side tests under `tools/tests/`.

The harness never transmits onto a CAN bus.

## Evidence already available from project reports

The existing W204 corpus contains timestamped recordings covering ignition/start, gear changes and dual-bus operation. The Stage 4/5 timestamped analysis records, for example, four core captures with 6,145–36,050 frames and separate CAN1/CAN2 populations, and identifies `0x0F1`/`0x17D` as CAN2 drivetrain traffic with cross-domain `0x0F3`, `0x105` and `0x1CD` representations. The project also explicitly requires differential comparison of ID, DLC, payload, period, first-send timing, MC, CRC, state dependency and transition dependency.

## Current verdict

- Harness parser/tests: **PASS**
- Firmware baseline inspection: **PASS for presence of RX/trace/state pipeline; TX remains compile-time gated**
- Actual reference-capture replay in this runtime: **NOT EXECUTED** because the raw RTF capture files are not available as directly materializable file objects in the current runtime; report PDFs confirm their existence and statistics, but they are not sufficient to replay every raw frame.
- Vehicle connection: **NOT PERFORMED**

## Next 10C acceptance step

Provide/mount the raw RTF capture files used in the Phase 8/9 evidence corpus. Then run:

```text
python tools/replay_diff.py <reference.rtf> --observed <translator_output.rtf>
```

The resulting differential record becomes the Phase 10C evidence artifact.

## Guardrails retained

No speculative `0x17D` slip law, `0x1CD` torque-arbitration law, M113 torque source, RPM scaling, `0x03F` startup law, `0x30D`/`0x349`, or `0x1D3` mandatory path was added.
