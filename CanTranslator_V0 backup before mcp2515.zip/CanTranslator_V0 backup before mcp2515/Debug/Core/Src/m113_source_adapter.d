Core/Src/m113_source_adapter.o: ../Core/Src/m113_source_adapter.c \
 ../Core/Inc/m113_source_adapter.h ../Core/Inc/vehicle_state.h
../Core/Inc/m113_source_adapter.h:
../Core/Inc/vehicle_state.h:
