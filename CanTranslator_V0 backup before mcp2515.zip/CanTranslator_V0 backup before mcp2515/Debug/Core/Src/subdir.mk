################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/bench_loopback.c \
../Core/Src/bench_tx_test.c \
../Core/Src/can_bus.c \
../Core/Src/can_trace.c \
../Core/Src/crc8_j1850.c \
../Core/Src/decoders.c \
../Core/Src/frame_integrity.c \
../Core/Src/m113_source_adapter.c \
../Core/Src/main.c \
../Core/Src/main_loop_integration.c \
../Core/Src/stm32f4xx_hal_msp.c \
../Core/Src/stm32f4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f4xx.c \
../Core/Src/translator_app.c \
../Core/Src/tx_protocol.c \
../Core/Src/tx_scheduler.c 

OBJS += \
./Core/Src/bench_loopback.o \
./Core/Src/bench_tx_test.o \
./Core/Src/can_bus.o \
./Core/Src/can_trace.o \
./Core/Src/crc8_j1850.o \
./Core/Src/decoders.o \
./Core/Src/frame_integrity.o \
./Core/Src/m113_source_adapter.o \
./Core/Src/main.o \
./Core/Src/main_loop_integration.o \
./Core/Src/stm32f4xx_hal_msp.o \
./Core/Src/stm32f4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f4xx.o \
./Core/Src/translator_app.o \
./Core/Src/tx_protocol.o \
./Core/Src/tx_scheduler.o 

C_DEPS += \
./Core/Src/bench_loopback.d \
./Core/Src/bench_tx_test.d \
./Core/Src/can_bus.d \
./Core/Src/can_trace.d \
./Core/Src/crc8_j1850.d \
./Core/Src/decoders.d \
./Core/Src/frame_integrity.d \
./Core/Src/m113_source_adapter.d \
./Core/Src/main.d \
./Core/Src/main_loop_integration.d \
./Core/Src/stm32f4xx_hal_msp.d \
./Core/Src/stm32f4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f4xx.d \
./Core/Src/translator_app.d \
./Core/Src/tx_protocol.d \
./Core/Src/tx_scheduler.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/bench_loopback.cyclo ./Core/Src/bench_loopback.d ./Core/Src/bench_loopback.o ./Core/Src/bench_loopback.su ./Core/Src/bench_tx_test.cyclo ./Core/Src/bench_tx_test.d ./Core/Src/bench_tx_test.o ./Core/Src/bench_tx_test.su ./Core/Src/can_bus.cyclo ./Core/Src/can_bus.d ./Core/Src/can_bus.o ./Core/Src/can_bus.su ./Core/Src/can_trace.cyclo ./Core/Src/can_trace.d ./Core/Src/can_trace.o ./Core/Src/can_trace.su ./Core/Src/crc8_j1850.cyclo ./Core/Src/crc8_j1850.d ./Core/Src/crc8_j1850.o ./Core/Src/crc8_j1850.su ./Core/Src/decoders.cyclo ./Core/Src/decoders.d ./Core/Src/decoders.o ./Core/Src/decoders.su ./Core/Src/frame_integrity.cyclo ./Core/Src/frame_integrity.d ./Core/Src/frame_integrity.o ./Core/Src/frame_integrity.su ./Core/Src/m113_source_adapter.cyclo ./Core/Src/m113_source_adapter.d ./Core/Src/m113_source_adapter.o ./Core/Src/m113_source_adapter.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/main_loop_integration.cyclo ./Core/Src/main_loop_integration.d ./Core/Src/main_loop_integration.o ./Core/Src/main_loop_integration.su ./Core/Src/stm32f4xx_hal_msp.cyclo ./Core/Src/stm32f4xx_hal_msp.d ./Core/Src/stm32f4xx_hal_msp.o ./Core/Src/stm32f4xx_hal_msp.su ./Core/Src/stm32f4xx_it.cyclo ./Core/Src/stm32f4xx_it.d ./Core/Src/stm32f4xx_it.o ./Core/Src/stm32f4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f4xx.cyclo ./Core/Src/system_stm32f4xx.d ./Core/Src/system_stm32f4xx.o ./Core/Src/system_stm32f4xx.su ./Core/Src/translator_app.cyclo ./Core/Src/translator_app.d ./Core/Src/translator_app.o ./Core/Src/translator_app.su ./Core/Src/tx_protocol.cyclo ./Core/Src/tx_protocol.d ./Core/Src/tx_protocol.o ./Core/Src/tx_protocol.su ./Core/Src/tx_scheduler.cyclo ./Core/Src/tx_scheduler.d ./Core/Src/tx_scheduler.o ./Core/Src/tx_scheduler.su

.PHONY: clean-Core-2f-Src

