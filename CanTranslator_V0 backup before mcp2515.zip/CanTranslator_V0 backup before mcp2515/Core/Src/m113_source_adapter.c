/*
 * m113_source_adapter.c
 *
 * Phase 10D source-adaptation boundary.
 */
#include "m113_source_adapter.h"

bool M113SourceAdapter_Apply(VehicleState_t *state)
{
    bool updated = false;

    if (!state) return false;

    if (state->m113_native.pedal_valid) {
        state->engine.pedal = state->m113_native.pedal_raw;
        updated = true;
    }

    if (state->m113_native.gear_valid && state->m113_native.normalized_gear <= 0x0Fu) {
        state->transmission.actual_gear = state->m113_native.normalized_gear;
        updated = true;
    }

    if (state->m113_native.rpm_valid) {
        /* Raw source value only. Physical RPM scaling remains explicitly open. */
        state->engine.actual_rpm_raw = (uint16_t)state->m113_native.rpm_raw;
        updated = true;
    }

    return updated;
}
