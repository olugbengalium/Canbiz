/*
 * main_loop_integration.c
 *
 * Bench receive/integrity/semantic integration point.
 *
 * This is deliberately not the final TX scheduler. It is the corrected
 * Phase 9E observation core: receive -> per-ID integrity policy -> MC
 * telemetry -> canonical decode -> trace.
 */

#include "can_bus.h"
#include "can_trace.h"
#include "crc8_j1850.h"
#include "frame_db.h"
#include "frame_integrity.h"
#include "decoders.h"
#include "vehicle_state.h"
#include "m113_source_adapter.h"
#include "tx_scheduler.h"
#include "bench_tx_test.h"

static VehicleState_t s_vehicle_state;
static FrameMcTracker_t s_mc_trackers[FRAME_DB_COUNT];

/* Phase 10F compact integrity self-test: one good frame, one bad CRC. */
static volatile bool s_fault_test_done;
static volatile bool s_fault_good_valid;
static volatile bool s_fault_bad_valid;

static int FrameDb_IndexOf(const FrameDbEntry_t *entry)
{
    if (!entry) return -1;
    return (int)(entry - FrameDb_Table);
}

static void RunCompactFaultTest(void)
{
    if (s_fault_test_done) return;

    const FrameDbEntry_t *entry = FrameDb_Find(0x105u);

    if (!entry) {
        s_fault_good_valid = false;
        s_fault_bad_valid = true;
        s_fault_test_done = true;
        return;
    }

    /*
     * Known-good protected 0x105 bench frame already proven in Phase 10E:
     * 90 01 00 32 7D 00 00 D1
     */
    CanFrame_t good = {0};
    good.bus = CANBUS_1;
    good.id = 0x105u;
    good.dlc = 8u;

    const uint8_t good_data[8] = {
        0x90u, 0x01u, 0x00u, 0x32u,
        0x7Du, 0x00u, 0x00u, 0xD1u
    };

    for (uint8_t i = 0u; i < 8u; ++i) {
        good.data[i] = good_data[i];
    }

    s_fault_good_valid = FrameIntegrity_Validate(entry, &good);

    /*
     * Corrupt only the CRC byte. Everything else remains identical.
     * A correct integrity implementation must reject this frame.
     */
    CanFrame_t bad = good;
    bad.data[7] ^= 0x01u;

    s_fault_bad_valid = FrameIntegrity_Validate(entry, &bad);

    s_fault_test_done = true;
}

static void ProcessFrame(const CanFrame_t *frame)
{
    const FrameDbEntry_t *entry = FrameDb_Find(frame->id);
    TraceRecord_t rec = {0};

    rec.timestamp_us = frame->timestamp_us;
    rec.bus = frame->bus;
    rec.id = frame->id;
    rec.dlc = frame->dlc;

    for (uint8_t i = 0; i < frame->dlc && i < 8; ++i) {
        rec.data[i] = frame->data[i];
    }

    /*
     * Known frame: report unexpected-bus traffic but do not discard it in
     * the bench build. This keeps the evidence visible while the topology
     * is being validated.
     */
    if (entry && !FrameDb_IsExpectedBus(entry, frame->bus)) {
        rec.decoded = false;
        TraceLog_Push(&rec);
        return;
    }

    /* Deferred telemetry is observed only. */
    if (entry && entry->deferred) {
        rec.decoded = false;
        TraceLog_Push(&rec);
        return;
    }

    /*
     * Per-ID integrity policy. Unknown IDs are not rejected here because
     * M113 native source IDs (0x268/0x3A0/0x3D0) are intentionally allowed
     * to enter the source decoder without a fabricated CRC rule.
     */
    if (entry) {
        if (entry->integrity != FRAME_INTEGRITY_NONE) {
            rec.crc_checked = true;
            rec.crc_valid = FrameIntegrity_Validate(entry, frame);

            if (!rec.crc_valid) {
                TraceLog_Push(&rec);
                return;
            }
        }

        uint8_t mc = 0;
        if (FrameIntegrity_GetMc(entry, frame, &mc)) {
            int idx = FrameDb_IndexOf(entry);

            rec.mc_checked = true;
            rec.mc_value = mc;

            if (idx >= 0) {
                rec.mc_sequence_ok =
                    FrameIntegrity_UpdateMc(&s_mc_trackers[idx], mc);
            }
        }
    }

    rec.decoded = Decoders_Dispatch(frame, &s_vehicle_state);

    if (rec.decoded) {
        switch (frame->id) {
        case 0x268:
        case 0x3A0:
        case 0x3D0:
            (void)M113SourceAdapter_Apply(&s_vehicle_state);
            break;

        default:
            break;
        }
    }

    TraceLog_Push(&rec);
}

void MainLoop_Poll(void)
{
    CanFrame_t frame;

    while (CanBus_Dequeue(CANBUS_1, &frame)) {
        ProcessFrame(&frame);
    }

    while (CanBus_Dequeue(CANBUS_2, &frame)) {
        ProcessFrame(&frame);
    }

    /* One-time bench integrity fault check; no CAN TX is generated. */
    RunCompactFaultTest();

    /*
     * TX remains a separate main-context stage. Evidence-gated packers
     * refuse to transmit while their source/destination laws are open.
     */
    uint32_t now_us = CanBus_GetTimestampUs();
    BenchTxTest_Poll(now_us);
    TxScheduler_Poll(now_us, &s_vehicle_state);
}
