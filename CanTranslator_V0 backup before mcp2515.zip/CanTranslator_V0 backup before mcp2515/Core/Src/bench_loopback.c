#include "bench_loopback.h"
#include "can_bus.h"

#define BENCH_LOOPBACK_ENABLE   1
#define BENCH_LOOPBACK_PERIOD_US 100000u

static uint32_t s_next_tx_us = 0u;

void BenchLoopback_Init(void)
{
    s_next_tx_us = 0u;
}

void BenchLoopback_Poll(uint32_t now_us)
{
#if BENCH_LOOPBACK_ENABLE

    if ((int32_t)(now_us - s_next_tx_us) < 0) {
        return;
    }

    s_next_tx_us = now_us + BENCH_LOOPBACK_PERIOD_US;

    /* M113 0x3A0: P */
    {
        const uint8_t data[8] = {
            0x50u, 0x00u, 0x00u, 0x00u,
            0x00u, 0x00u, 0x00u, 0x00u
        };

        (void)CanBus_Transmit(
            CANBUS_2,
            0x3A0u,
            false,
            data,
            8u
        );
    }

    /* M113 0x268: pedal raw = 125 */
    {
        const uint8_t data[8] = {
            0x00u, 0x00u, 0x00u, 0x00u,
            0x00u, 125u, 0x00u, 0x00u
        };

        (void)CanBus_Transmit(
            CANBUS_2,
            0x268u,
            false,
            data,
            8u
        );
    }

    /* M113 0x3D0: raw RPM source = 100 */
    {
        const uint8_t data[8] = {
            0x00u, 100u, 0x00u, 0x00u,
            0x00u, 0x00u, 0x00u, 0x00u
        };

        (void)CanBus_Transmit(
            CANBUS_2,
            0x3D0u,
            false,
            data,
            8u
        );
    }

#else

    (void)now_us;

#endif
}
