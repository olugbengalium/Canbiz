#include "translator_app.h"
#include "can_bus.h"
#include "can_trace.h"
#include "tx_scheduler.h"
#include "bench_tx_test.h"

extern void MainLoop_Poll(void);

bool Translator_AppInit(void)
{
    TraceLog_Init();
    if (!CanBus_Init()) return false;
    BenchTxTest_Init();
    TxScheduler_Init();
    return true;
}

void Translator_AppPoll(void)
{
    MainLoop_Poll();
}
