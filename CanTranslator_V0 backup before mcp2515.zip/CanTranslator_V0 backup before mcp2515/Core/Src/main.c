/*
 * main.c
 *
 * CubeMX application entry point. Keep this file thin: peripheral ownership
 * stays here, translator logic stays in translator_app/main_loop modules.
 * This file matches CanTranslator_V0.ioc: STM32F407VGTx, 50 MHz system clock,
 * two 500-kbit/s bxCAN interfaces.
 */

#include "main.h"
#include "can_bus.h"
#include "translator_app.h"
#include "can_trace.h"
#include "crc8_j1850.h"
#include "frame_db.h"
#include "frame_integrity.h"
#include "decoders.h"
#include "vehicle_state.h"
#include "m113_source_adapter.h"
#include "tx_scheduler.h"
#include <stdio.h>

CAN_HandleTypeDef hcan1;
CAN_HandleTypeDef hcan2;

static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN1_Init(void);
static void MX_CAN2_Init(void);

/*
 * Redirect printf() to ITM/SWO.
 * CubeIDE SWV should be configured for the actual 50 MHz core clock.
 */
int _write(int file, char *ptr, int len)
{
    (void)file;

    for (int i = 0; i < len; i++)
    {
        ITM_SendChar((uint32_t)ptr[i]);
    }

    return len;
}

static void Debug_Test(void)
{
    printf("STM32F407 SWO TEST - SystemCoreClock=%lu Hz\r\n",
           (unsigned long)SystemCoreClock);
}

int main(void)
{
    HAL_Init();

    SystemClock_Config();

    MX_GPIO_Init();

    MX_CAN1_Init();

    MX_CAN2_Init();

    /*
     * Send a direct ITM message immediately, before the application starts.
     * This lets us test the SWV/ITM path independently of Translator_AppInit().
     */
    ITM_SendChar('H');
    ITM_SendChar('E');
    ITM_SendChar('L');
    ITM_SendChar('L');
    ITM_SendChar('O');
    ITM_SendChar('\r');
    ITM_SendChar('\n');

    if (!Translator_AppInit()) {
        Error_Handler();
    }

    while (1)
    {
        /*
         * Repeat the debug message once per second so the SWV receiver
         * cannot miss the startup message.
         */
        Debug_Test();

        Translator_AppPoll();

        HAL_Delay(1000);
    }
}

static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 4;
    RCC_OscInitStruct.PLL.PLLN = 50;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 2;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK |
                                  RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 |
                                  RCC_CLOCKTYPE_PCLK2;

    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK) {
        Error_Handler();
    }
}

static void MX_CAN1_Init(void)
{
    hcan1.Instance = CAN1;

    hcan1.Init.Prescaler = 5;
    hcan1.Init.Mode = CAN_MODE_NORMAL;
    hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
    hcan1.Init.TimeSeg1 = CAN_BS1_8TQ;
    hcan1.Init.TimeSeg2 = CAN_BS2_1TQ;
    hcan1.Init.TimeTriggeredMode = DISABLE;
    hcan1.Init.AutoBusOff = DISABLE;
    hcan1.Init.AutoWakeUp = DISABLE;
    hcan1.Init.AutoRetransmission = ENABLE;
    hcan1.Init.ReceiveFifoLocked = DISABLE;
    hcan1.Init.TransmitFifoPriority = DISABLE;

    if (HAL_CAN_Init(&hcan1) != HAL_OK) {
        Error_Handler();
    }
}

static void MX_CAN2_Init(void)
{
    hcan2.Instance = CAN2;

    hcan2.Init.Prescaler = 5;
    hcan2.Init.Mode = CAN_MODE_NORMAL;
    hcan2.Init.SyncJumpWidth = CAN_SJW_1TQ;
    hcan2.Init.TimeSeg1 = CAN_BS1_8TQ;
    hcan2.Init.TimeSeg2 = CAN_BS2_1TQ;
    hcan2.Init.TimeTriggeredMode = DISABLE;
    hcan2.Init.AutoBusOff = DISABLE;
    hcan2.Init.AutoWakeUp = DISABLE;
    hcan2.Init.AutoRetransmission = ENABLE;
    hcan2.Init.ReceiveFifoLocked = DISABLE;
    hcan2.Init.TransmitFifoPriority = DISABLE;

    if (HAL_CAN_Init(&hcan2) != HAL_OK) {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* CAN pins are configured in HAL_CAN_MspInit(). */
}

void Error_Handler(void)
{
    __disable_irq();

    while (1) {
    }
}

#ifdef USE_FULL_ASSERT

void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
    Error_Handler();
}

#endif
