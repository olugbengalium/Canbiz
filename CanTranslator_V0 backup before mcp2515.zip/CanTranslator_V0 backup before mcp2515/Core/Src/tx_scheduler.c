#include "tx_scheduler.h"
#include "can_bus.h"
#include "crc8_j1850.h"
#include "frame_db.h"
#include "tx_protocol.h"
#include "signal_anchors.h"
#include <string.h>

/* Periods come from the empirical frame database. TX remains disabled by
 * default; these intervals are the scheduler's destination timing contract. */
typedef struct {
    uint32_t next_due_us;
    uint8_t mc;
} TxFrameRuntime_t;

static TxFrameRuntime_t s_0f3;
static TxFrameRuntime_t s_105;
static TxFrameRuntime_t s_14b;
static TxFrameRuntime_t s_17d;
static TxFrameRuntime_t s_1cd;
static bool s_enabled;
static uint32_t s_attempt_count;
static uint32_t s_gate_count;

/*
 * Phase 10E combined scheduler observation.
 *
 * This mode is intentionally independent of TRANSLATOR_TX_ENABLE:
 * it runs the normal scheduler's pack/MC/CRC decisions but NEVER calls
 * CanBus_Transmit(). It gives the debugger a single snapshot of the complete
 * W204 output set without enabling production TX.
 */
#define TX_SCHEDULER_OBSERVE_ENABLE 1

/*
 * First vehicle-connection safety latch.
 *
 * Keep this at 0 for passive vehicle observation. Production TX requires
 * BOTH TRANSLATOR_TX_ENABLE and this explicit arm to be non-zero.
 */
#define TRANSLATOR_VEHICLE_TX_ARM 0

typedef struct {
    uint32_t poll_count;
    uint32_t generated_mask;
    uint32_t gated_mask;

    uint32_t id[4];
    uint8_t  dlc[4];
    uint8_t  data[4][8];
    uint8_t  mc[4];
    uint8_t  crc[4];
    uint8_t  pack_ok[4];
} TxSchedulerObserve_t;

static volatile TxSchedulerObserve_t s_observe;
static TxFrameRuntime_t s_obs_105;
static TxFrameRuntime_t s_obs_14b;
static TxFrameRuntime_t s_obs_17d;
static TxFrameRuntime_t s_obs_1cd;

enum {
    OBS_INDEX_105  = 0u,
    OBS_INDEX_14B  = 1u,
    OBS_INDEX_17D  = 2u,
    OBS_INDEX_1CD  = 3u
};

/* Forward declarations used by the observation helpers below. */
static bool Due(uint32_t now_us, uint32_t due_us);
static uint8_t PeekMc(const TxFrameRuntime_t *runtime);
static void CommitMc(TxFrameRuntime_t *runtime);
static void ScheduleNext(TxFrameRuntime_t *runtime, uint32_t now_us,
                         uint16_t period_ms);
static void BuildOutputConfig(const VehicleState_t *state,
                              TxOutputConfig_t *cfg);

static void ObserveOutput(uint32_t now_us,
                          const VehicleState_t *state,
                          TxFrameRuntime_t *runtime,
                          uint32_t id,
                          uint16_t period_ms,
                          uint8_t index,
                          uint32_t validity_bit)
{
    if (!Due(now_us, runtime->next_due_us)) return;

    TxOutputConfig_t cfg;
    uint8_t data[8] = {0u};

    BuildOutputConfig(state, &cfg);

    /*
     * Observation mode deliberately marks the geometry as packable so that
     * the combined scheduler can be inspected end-to-end. This does NOT
     * enable transmission and does NOT close any open source/control law.
     */
    cfg.valid_mask |= validity_bit;

    const uint8_t mc = PeekMc(runtime);
    const TxPackResult_t result =
        (index == OBS_INDEX_105) ? TxProtocol_Pack0x105(&cfg, mc, data) :
        (index == OBS_INDEX_14B) ? TxProtocol_Pack0x14B(&cfg, mc, data) :
        (index == OBS_INDEX_17D) ? TxProtocol_Pack0x17D(&cfg, mc, data) :
                                   TxProtocol_Pack0x1CD(&cfg, mc, data);

    s_observe.id[index] = id;
    s_observe.dlc[index] = 8u;
    s_observe.mc[index] = mc;
    s_observe.pack_ok[index] = (result == TX_PACK_OK) ? 1u : 0u;

    if (result == TX_PACK_OK) {
        Crc8_J1850_StampFrame(data);
        for (uint8_t i = 0u; i < 8u; ++i) {
            s_observe.data[index][i] = data[i];
        }
        s_observe.crc[index] = data[7];
        s_observe.generated_mask |= (1u << index);

        /*
         * Observation only: advance the local observation MC exactly as the
         * real scheduler would after a successful send.
         */
        CommitMc(runtime);
    } else {
        s_observe.gated_mask |= (1u << index);
    }

    ScheduleNext(runtime, now_us, period_ms);
}

static void ObserveCombinedScheduler(uint32_t now_us,
                                     const VehicleState_t *state)
{
#if TX_SCHEDULER_OBSERVE_ENABLE
    if (!state) return;

    ++s_observe.poll_count;

    const FrameDbEntry_t *e105  = FrameDb_Find(CAN_ID_ENGINE_PUB);
    const FrameDbEntry_t *e14b  = FrameDb_Find(CAN_ID_TORQUE_PUB);
    const FrameDbEntry_t *e17d  = FrameDb_Find(CAN_ID_ECU_PT_RESPONSE);
    const FrameDbEntry_t *e1cd  = FrameDb_Find(CAN_ID_TORQUE_ARBITRATION);

    if (e105) ObserveOutput(now_us, state, &s_obs_105,
                            CAN_ID_ENGINE_PUB, e105->nominal_period_ms,
                            OBS_INDEX_105, TX_CFG_105_COMPLETE);
    if (e14b) ObserveOutput(now_us, state, &s_obs_14b,
                            CAN_ID_TORQUE_PUB, e14b->nominal_period_ms,
                            OBS_INDEX_14B, TX_CFG_14B_COMPLETE);
    if (e17d) ObserveOutput(now_us, state, &s_obs_17d,
                            CAN_ID_ECU_PT_RESPONSE, e17d->nominal_period_ms,
                            OBS_INDEX_17D, TX_CFG_17D_COMPLETE);
    if (e1cd) ObserveOutput(now_us, state, &s_obs_1cd,
                            CAN_ID_TORQUE_ARBITRATION, e1cd->nominal_period_ms,
                            OBS_INDEX_1CD, TX_CFG_1CD_COMPLETE);
#else
    (void)now_us;
    (void)state;
#endif
}

static bool Due(uint32_t now_us, uint32_t due_us)
{
    return (int32_t)(now_us - due_us) >= 0;
}

static uint8_t PeekMc(const TxFrameRuntime_t *runtime)
{
    return (uint8_t)(runtime->mc & 0x0Fu);
}

static void CommitMc(TxFrameRuntime_t *runtime)
{
    runtime->mc = (uint8_t)((runtime->mc + 1u) & 0x0Fu);
}

static void ScheduleNext(TxFrameRuntime_t *runtime, uint32_t now_us,
                         uint16_t period_ms)
{
    runtime->next_due_us = now_us + ((uint32_t)period_ms * 1000u);
}

static void BuildOutputConfig(const VehicleState_t *state, TxOutputConfig_t *cfg)
{
    TxProtocol_OutputConfigInit(cfg);
    if (!state || !cfg) return;

    /* Copy only already-modelled state into the output framework. The
     * validity mask remains clear until the corresponding source/control law
     * is proven. This lets Phase 10E exercise geometry without transmitting
     * guessed values. */
    cfg->engine_rpm_raw = state->engine.actual_rpm_raw;
    cfg->accel_pedal_raw = state->engine.pedal;

    cfg->torque_static_raw = state->engine.torque_static_raw;
    cfg->torque_max_raw = state->engine.torque_max_raw;
    cfg->torque_min_raw = state->engine.torque_min_raw;

    cfg->gr_max_rq = state->transmission.gr_max_rq;
    cfg->gr_min_rq = state->transmission.gr_min_rq;
    cfg->creep_off_rq = state->transmission.creep_off_rq ? 1u : 0u;
    cfg->gr1_rq = state->transmission.gr1_rq ? 1u : 0u;
    cfg->shift_char_display = state->transmission.shift_state;
    cfg->tcc_rq = state->transmission.tcc_state;
    cfg->tx_slip_rpm_rq = state->transmission.tx_slip_rpm_rq;

    cfg->trq_sel_d_ttc_raw = state->transmission.trq_sel_d_ttc_raw;
    cfg->trq_sel_as_ttc_raw = state->transmission.trq_sel_as_ttc_raw;
    cfg->trq_sel_sbc_ttc_raw = state->transmission.trq_sel_sbc_ttc_raw;
}

static void TrySend0x105(uint32_t now_us, const VehicleState_t *state)
{
    uint8_t data[8] = {0};
    TxOutputConfig_t cfg;
    BuildOutputConfig(state, &cfg);
    ++s_attempt_count;
    const uint8_t mc = PeekMc(&s_105);
    if (TxProtocol_Pack0x105(&cfg, mc, data) == TX_PACK_OK) {
        Crc8_J1850_StampFrame(data);
        if (CanBus_Transmit(CANBUS_2, CAN_ID_ENGINE_PUB, false, data, 8u))
            CommitMc(&s_105);
    } else ++s_gate_count;
    ScheduleNext(&s_105, now_us, FrameDb_Find(CAN_ID_ENGINE_PUB)->nominal_period_ms);
}

static void TrySend0x14B(uint32_t now_us, const VehicleState_t *state)
{
    uint8_t data[8] = {0};
    TxOutputConfig_t cfg;
    BuildOutputConfig(state, &cfg);
    ++s_attempt_count;
    const uint8_t mc = PeekMc(&s_14b);
    if (TxProtocol_Pack0x14B(&cfg, mc, data) == TX_PACK_OK) {
        Crc8_J1850_StampFrame(data);
        if (CanBus_Transmit(CANBUS_2, CAN_ID_TORQUE_PUB, false, data, 8u))
            CommitMc(&s_14b);
    } else ++s_gate_count;
    ScheduleNext(&s_14b, now_us, FrameDb_Find(CAN_ID_TORQUE_PUB)->nominal_period_ms);
}

static void TrySend0x17D(uint32_t now_us, const VehicleState_t *state)
{
    uint8_t data[8] = {0};
    TxOutputConfig_t cfg;
    BuildOutputConfig(state, &cfg);
    ++s_attempt_count;
    const uint8_t mc = PeekMc(&s_17d);
    if (TxProtocol_Pack0x17D(&cfg, mc, data) == TX_PACK_OK) {
        Crc8_J1850_StampFrame(data);
        if (CanBus_Transmit(CANBUS_2, CAN_ID_ECU_PT_RESPONSE, false, data, 8u))
            CommitMc(&s_17d);
    } else ++s_gate_count;
    ScheduleNext(&s_17d, now_us, FrameDb_Find(CAN_ID_ECU_PT_RESPONSE)->nominal_period_ms);
}

static void TrySend0x1CD(uint32_t now_us, const VehicleState_t *state)
{
    uint8_t data[8] = {0};
    TxOutputConfig_t cfg;
    BuildOutputConfig(state, &cfg);
    ++s_attempt_count;
    const uint8_t mc = PeekMc(&s_1cd);
    if (TxProtocol_Pack0x1CD(&cfg, mc, data) == TX_PACK_OK) {
        Crc8_J1850_StampFrame(data);
        if (CanBus_Transmit(CANBUS_2, CAN_ID_TORQUE_ARBITRATION, false, data, 8u))
            CommitMc(&s_1cd);
    } else ++s_gate_count;
    ScheduleNext(&s_1cd, now_us, FrameDb_Find(CAN_ID_TORQUE_ARBITRATION)->nominal_period_ms);
}

void TxScheduler_Init(void)
{
    memset(&s_0f3, 0, sizeof(s_0f3));
    memset(&s_105, 0, sizeof(s_105));
    memset(&s_14b, 0, sizeof(s_14b));
    memset(&s_17d, 0, sizeof(s_17d));
    memset(&s_1cd, 0, sizeof(s_1cd));
    s_enabled = (TRANSLATOR_TX_ENABLE != 0) &&
                 (TRANSLATOR_VEHICLE_TX_ARM != 0);
    s_attempt_count = 0u;
    s_gate_count = 0u;

    s_obs_105 = (TxFrameRuntime_t){0};
    s_obs_14b = (TxFrameRuntime_t){0};
    s_obs_17d = (TxFrameRuntime_t){0};
    s_obs_1cd = (TxFrameRuntime_t){0};
    s_observe = (TxSchedulerObserve_t){0};
}

void TxScheduler_SetEnabled(bool enabled)
{
    /* Runtime enable is still subordinate to the compile-time safety gate. */
    s_enabled = enabled &&
                 (TRANSLATOR_TX_ENABLE != 0) &&
                 (TRANSLATOR_VEHICLE_TX_ARM != 0);
}

bool TxScheduler_IsEnabled(void)
{
    return s_enabled;
}

uint32_t TxScheduler_GetAttemptCount(void)
{
    return s_attempt_count;
}

uint32_t TxScheduler_GetGateCount(void)
{
    return s_gate_count;
}

void TxScheduler_Poll(uint32_t now_us, const VehicleState_t *state)
{
    if (!state) return;

    ObserveCombinedScheduler(now_us, state);

    if (!s_enabled) return;

    if (Due(now_us, s_105.next_due_us)) TrySend0x105(now_us, state);
    if (Due(now_us, s_14b.next_due_us)) TrySend0x14B(now_us, state);
    if (Due(now_us, s_17d.next_due_us)) TrySend0x17D(now_us, state);
    if (Due(now_us, s_1cd.next_due_us)) TrySend0x1CD(now_us, state);
}
