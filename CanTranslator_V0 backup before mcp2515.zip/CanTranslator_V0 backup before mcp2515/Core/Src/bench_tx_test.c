#include "bench_tx_test.h"
#include "can_bus.h"
#include "crc8_j1850.h"
#include "tx_protocol.h"

#define BENCH_TX_TEST_ENABLE       0
#define BENCH_TX_TEST_PERIOD_US    100000u
#define BENCH_TX_TEST_FRAME_ID     0x17Du

/* 0x17D B1 behavior is still OPEN in Phase 10.
 * Keep the bench choice explicit/configurable rather than treating it as closed.
 */
#define BENCH_17D_B1_MODE          0x20u

static uint32_t s_next_tx_us;
static volatile bool s_tx_ok;
static volatile uint32_t s_tx_attempts;

void BenchTxTest_Init(void)
{
    s_next_tx_us = 0u;
}

void BenchTxTest_Poll(uint32_t now_us)
{
#if BENCH_TX_TEST_ENABLE
    if ((int32_t)(now_us - s_next_tx_us) < 0) {
        return;
    }

    s_next_tx_us = now_us + BENCH_TX_TEST_PERIOD_US;

    /*
     * Controlled 0x17D wire-format bench test.
     *
     * Purpose ONLY:
     *   pack -> MC -> J1850 CRC -> CAN2 TX -> CAN1 RX
     *
     * The 0x17D control law is NOT being solved here.
     * The slip-target law (G1) and B1 mode remain configurable/open.
     */
    TxOutputConfig_t cfg;
    TxProtocol_OutputConfigInit(&cfg);

    /* Closed field geometry; synthetic bench values only. */
    cfg.gr_max_rq          = 1u;
    cfg.gr_min_rq          = 2u;
    cfg.creep_off_rq       = 1u;
    cfg.gr1_rq             = 1u;
    cfg.shift_char_display = 0xAu;
    cfg.tcc_rq             = 1u;

    /* G1 is open: use a fixed synthetic value only to exercise the bit field. */
    cfg.tx_slip_rpm_rq     = 100u;

    cfg.valid_mask = TX_CFG_17D_COMPLETE;

    uint8_t data[8] = {0u};
    const uint8_t mc = 0u;

    if (TxProtocol_Pack0x17D(&cfg, mc, data) != TX_PACK_OK) {
        return;
    }

    /*
     * B1 mode is explicitly unresolved in Phase 10. For this isolated bench
     * transport test, expose the chosen candidate byte rather than silently
     * presenting it as a solved behavioral law.
     */
    data[1] = BENCH_17D_B1_MODE;

    Crc8_J1850_StampFrame(data);

    s_tx_ok = CanBus_Transmit(
        CANBUS_2,
        BENCH_TX_TEST_FRAME_ID,
        false,
        data,
        8u
    );

    if (!s_tx_ok) {
        return;
    }
#else
    (void)now_us;
#endif
}
