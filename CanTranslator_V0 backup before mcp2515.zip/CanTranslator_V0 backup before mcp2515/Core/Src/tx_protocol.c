#include "tx_protocol.h"
#include "signal_anchors.h"
#include <string.h>

void TxProtocol_SetBitsLE(uint8_t data[8], uint8_t start_bit,
                          uint8_t bit_len, uint32_t value)
{
    if (!data || bit_len == 0u || bit_len > 32u ||
        ((uint16_t)start_bit + (uint16_t)bit_len) > 64u) return;

    for (uint8_t i = 0u; i < bit_len; ++i) {
        const uint8_t bit = (uint8_t)(start_bit + i);
        const uint8_t mask = (uint8_t)(1u << (bit & 7u));
        if (((value >> i) & 1u) != 0u) data[bit / 8u] |= mask;
        else data[bit / 8u] &= (uint8_t)~mask;
    }
}

void TxProtocol_OutputConfigInit(TxOutputConfig_t *cfg)
{
    if (cfg) memset(cfg, 0, sizeof(*cfg));
}

TxPackResult_t TxProtocol_Pack0x105(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8])
{
    if (!cfg || !data) return TX_PACK_INVALID_ARG;
    if ((cfg->valid_mask & TX_CFG_105_COMPLETE) == 0u) return TX_PACK_GATED;

    memset(data, 0, 8u);
    TxProtocol_SetBitsLE(data, SIG_0x105_KickDnSw_Psd_BIT,
                         SIG_0x105_KickDnSw_Psd_LEN, cfg->kickdown & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x105_PreHt_Stat_BIT,
                         SIG_0x105_PreHt_Stat_LEN, cfg->preheat & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x105_EngRPM_BIT,
                         SIG_0x105_EngRPM_LEN, cfg->engine_rpm_raw & 0x3FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x105_EngTrqMaxCorrFctr_BIT,
                         SIG_0x105_EngTrqMaxCorrFctr_LEN, cfg->torque_max_corr);
    TxProtocol_SetBitsLE(data, SIG_0x105_AccelPdlPosn_BIT,
                         SIG_0x105_AccelPdlPosn_LEN, cfg->accel_pedal);
    TxProtocol_SetBitsLE(data, SIG_0x105_AccelPdlPosn_Raw_BIT,
                         SIG_0x105_AccelPdlPosn_Raw_LEN, cfg->accel_pedal_raw);
    TxProtocol_SetBitsLE(data, SIG_0x105_Term61_Actv_BIT,
                         SIG_0x105_Term61_Actv_LEN, cfg->term61_active & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x105_AddPwrCnsmr_On_Rq_BIT,
                         SIG_0x105_AddPwrCnsmr_On_Rq_LEN, cfg->add_power_consumer & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x105_GenLoad_BIT,
                         SIG_0x105_GenLoad_LEN, cfg->gen_load & 0x3Fu);
    TxProtocol_SetBitsLE(data, SIG_0x105_MC_BIT, SIG_0x105_MC_LEN, mc & 0x0Fu);
    return TX_PACK_OK;
}

TxPackResult_t TxProtocol_Pack0x14B(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8])
{
    if (!cfg || !data) return TX_PACK_INVALID_ARG;
    if ((cfg->valid_mask & TX_CFG_14B_COMPLETE) == 0u) return TX_PACK_GATED;

    memset(data, 0, 8u);
    TxProtocol_SetBitsLE(data, SIG_0x14B_EngTrqStatic_BIT,
                         SIG_0x14B_EngTrqStatic_LEN, cfg->torque_static_raw & 0x1FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x14B_EngTrqMaxETC_BIT,
                         SIG_0x14B_EngTrqMaxETC_LEN, cfg->torque_max_raw & 0x1FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x14B_EngTrqMinTTC_BIT,
                         SIG_0x14B_EngTrqMinTTC_LEN, cfg->torque_min_raw & 0x1FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x14B_FullOFC_Actv_BIT,
                         SIG_0x14B_FullOFC_Actv_LEN, cfg->full_ofc_active & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x14B_PartOFC_Actv_BIT,
                         SIG_0x14B_PartOFC_Actv_LEN, cfg->part_ofc_active & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x14B_MC_BIT, SIG_0x14B_MC_LEN, mc & 0x0Fu);
    return TX_PACK_OK;
}

TxPackResult_t TxProtocol_Pack0x17D(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8])
{
    if (!cfg || !data) return TX_PACK_INVALID_ARG;
    if ((cfg->valid_mask & TX_CFG_17D_COMPLETE) == 0u) return TX_PACK_GATED;

    memset(data, 0, 8u);
    TxProtocol_SetBitsLE(data, SIG_0x17D_GrMax_Rq_ECM_BIT,
                         SIG_0x17D_GrMax_Rq_ECM_LEN, cfg->gr_max_rq & 0x07u);
    TxProtocol_SetBitsLE(data, SIG_0x17D_GrMin_Rq_ECM_BIT,
                         SIG_0x17D_GrMin_Rq_ECM_LEN, cfg->gr_min_rq & 0x07u);
    TxProtocol_SetBitsLE(data, SIG_0x17D_Creep_Off_Rq_BIT,
                         SIG_0x17D_Creep_Off_Rq_LEN, cfg->creep_off_rq & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x17D_Gr1_Rq_ECM_BIT,
                         SIG_0x17D_Gr1_Rq_ECM_LEN, cfg->gr1_rq & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x17D_ShftChrDsp_Rq_BIT,
                         SIG_0x17D_ShftChrDsp_Rq_LEN, cfg->shift_char_display & 0x0Fu);
    TxProtocol_SetBitsLE(data, SIG_0x17D_TCC_Rq_BIT,
                         SIG_0x17D_TCC_Rq_LEN, cfg->tcc_rq & 0x03u);
    TxProtocol_SetBitsLE(data, SIG_0x17D_TxSlpRPM_Rq_ECM_BIT,
                         SIG_0x17D_TxSlpRPM_Rq_ECM_LEN, cfg->tx_slip_rpm_rq & 0x3FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x17D_MC_BIT, SIG_0x17D_MC_LEN, mc & 0x0Fu);
    return TX_PACK_OK;
}

TxPackResult_t TxProtocol_Pack0x1CD(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8])
{
    if (!cfg || !data) return TX_PACK_INVALID_ARG;
    if ((cfg->valid_mask & TX_CFG_1CD_COMPLETE) == 0u) return TX_PACK_GATED;

    memset(data, 0, 8u);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrq_Enbl_Rq_AS_BIT,
                         SIG_0x1CD_EngTrq_Enbl_Rq_AS_LEN, cfg->trq_enbl_rq_as & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrqSel_D_TTC_BIT,
                         SIG_0x1CD_EngTrqSel_D_TTC_LEN, cfg->trq_sel_d_ttc_raw & 0x1FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrqAdjFast_Enbl_BIT,
                         SIG_0x1CD_EngTrqAdjFast_Enbl_LEN, cfg->trq_adj_fast_enbl & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrq_Enbl_Rq_SBC_BIT,
                         SIG_0x1CD_EngTrq_Enbl_Rq_SBC_LEN, cfg->trq_enbl_rq_sbc & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrqSel_AS_TTC_BIT,
                         SIG_0x1CD_EngTrqSel_AS_TTC_LEN, cfg->trq_sel_as_ttc_raw & 0x1FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrq_Ack_ECM_BIT,
                         SIG_0x1CD_EngTrq_Ack_ECM_LEN, cfg->trq_ack_ecm & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrq_Enbl_Rq_TCM_BIT,
                         SIG_0x1CD_EngTrq_Enbl_Rq_TCM_LEN, cfg->trq_enbl_rq_tcm & 1u);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_EngTrqSel_SBC_TTC_BIT,
                         SIG_0x1CD_EngTrqSel_SBC_TTC_LEN, cfg->trq_sel_sbc_ttc_raw & 0x1FFFu);
    TxProtocol_SetBitsLE(data, SIG_0x1CD_MC_BIT, SIG_0x1CD_MC_LEN, mc & 0x0Fu);
    return TX_PACK_OK;
}
