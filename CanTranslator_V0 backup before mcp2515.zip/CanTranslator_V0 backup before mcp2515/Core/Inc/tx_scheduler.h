#ifndef TX_SCHEDULER_H
#define TX_SCHEDULER_H

#include "vehicle_state.h"
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* TX is disabled by default until the source->destination mappings are
 * closed and validated against a reference W204 recording. */
#ifndef TRANSLATOR_TX_ENABLE
#define TRANSLATOR_TX_ENABLE 0
#endif

void TxScheduler_Init(void);
void TxScheduler_Poll(uint32_t now_us, const VehicleState_t *state);
void TxScheduler_SetEnabled(bool enabled);
bool TxScheduler_IsEnabled(void);
uint32_t TxScheduler_GetAttemptCount(void);
uint32_t TxScheduler_GetGateCount(void);

#ifdef __cplusplus
}
#endif
#endif /* TX_SCHEDULER_H */
