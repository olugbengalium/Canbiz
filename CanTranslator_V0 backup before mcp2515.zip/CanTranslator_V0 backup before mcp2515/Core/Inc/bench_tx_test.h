#ifndef BENCH_TX_TEST_H
#define BENCH_TX_TEST_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Temporary Phase 10E bench-only output test. */
void BenchTxTest_Init(void);
void BenchTxTest_Poll(uint32_t now_us);

#ifdef __cplusplus
}
#endif

#endif /* BENCH_TX_TEST_H */
