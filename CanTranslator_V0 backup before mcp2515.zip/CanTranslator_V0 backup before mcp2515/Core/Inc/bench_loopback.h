#ifndef BENCH_LOOPBACK_H
#define BENCH_LOOPBACK_H

#include <stdint.h>

void BenchLoopback_Init(void);
void BenchLoopback_Poll(uint32_t now_us);

#endif
