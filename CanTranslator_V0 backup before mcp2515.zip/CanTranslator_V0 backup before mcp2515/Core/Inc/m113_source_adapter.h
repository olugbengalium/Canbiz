/*
 * m113_source_adapter.h
 *
 * Phase 10D — M113 native-source integration.
 *
 * Copies only confirmed M113 source anchors into the canonical VehicleState:
 *   0x268 B5 -> EngineState.pedal
 *   0x3A0 B0 -> TransmissionState.actual_gear
 *   0x3D0 B1 -> EngineState.actual_rpm_raw
 *
 * No physical RPM scaling is applied, and target_gear is deliberately not
 * synthesized from actual_gear. Those behaviors remain outside the closed
 * evidence boundary.
 */
#ifndef M113_SOURCE_ADAPTER_H
#define M113_SOURCE_ADAPTER_H

#include <stdbool.h>
#include "vehicle_state.h"

#ifdef __cplusplus
extern "C" {
#endif

bool M113SourceAdapter_Apply(VehicleState_t *state);

#ifdef __cplusplus
}
#endif

#endif /* M113_SOURCE_ADAPTER_H */
