#ifndef TX_PROTOCOL_H
#define TX_PROTOCOL_H

#include "can_bus.h"
#include "vehicle_state.h"
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Phase 10E destination-output framework.
 *
 * The Phase 8/9 state report authorizes the W204 bit geometry, CRC policy and
 * independent MC state, but explicitly leaves several source/control laws
 * open.  Therefore these packers only emit a complete frame when the caller
 * explicitly marks the corresponding configuration as valid.  No guessed
 * zero/default is silently promoted to a live protocol value.
 */
typedef enum {
    TX_PACK_OK = 0,
    TX_PACK_GATED,
    TX_PACK_INVALID_ARG
} TxPackResult_t;

typedef enum {
    TX_CFG_105_COMPLETE = (1u << 0),
    TX_CFG_14B_COMPLETE = (1u << 1),
    TX_CFG_17D_COMPLETE = (1u << 2),
    TX_CFG_1CD_COMPLETE = (1u << 3)
} TxOutputValidity_t;

typedef struct {
    /* 0x105 — only fields whose final source mapping is explicitly supplied
     * by the caller may be transmitted.  The MC occupies bits 52..55, so the
     * previously extracted fields in that nibble remain quarantined. */
    uint8_t  kickdown;
    uint8_t  preheat;
    uint16_t engine_rpm_raw;
    uint8_t  torque_max_corr;
    uint8_t  accel_pedal;
    uint8_t  accel_pedal_raw;
    uint8_t  term61_active;
    uint8_t  add_power_consumer;
    uint8_t  gen_load;

    /* 0x14B */
    uint16_t torque_static_raw;
    uint16_t torque_max_raw;
    uint16_t torque_min_raw;
    uint8_t  full_ofc_active;
    uint8_t  part_ofc_active;

    /* 0x17D */
    uint8_t  gr_max_rq;
    uint8_t  gr_min_rq;
    uint8_t  creep_off_rq;
    uint8_t  gr1_rq;
    uint8_t  shift_char_display;
    uint8_t  tcc_rq;
    uint16_t tx_slip_rpm_rq;

    /* 0x1CD */
    uint8_t  trq_enbl_rq_as;
    uint16_t trq_sel_d_ttc_raw;
    uint8_t  trq_adj_fast_enbl;
    uint8_t  trq_enbl_rq_sbc;
    uint16_t trq_sel_as_ttc_raw;
    uint8_t  trq_ack_ecm;
    uint8_t  trq_enbl_rq_tcm;
    uint16_t trq_sel_sbc_ttc_raw;

    uint32_t valid_mask;
} TxOutputConfig_t;

void TxProtocol_SetBitsLE(uint8_t data[8], uint8_t start_bit,
                          uint8_t bit_len, uint32_t value);

void TxProtocol_OutputConfigInit(TxOutputConfig_t *cfg);

TxPackResult_t TxProtocol_Pack0x105(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8]);
TxPackResult_t TxProtocol_Pack0x14B(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8]);
TxPackResult_t TxProtocol_Pack0x17D(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8]);
TxPackResult_t TxProtocol_Pack0x1CD(const TxOutputConfig_t *cfg,
                                    uint8_t mc, uint8_t data[8]);

#ifdef __cplusplus
}
#endif
#endif /* TX_PROTOCOL_H */
